import { Button } from "./Button"

export function Add(){
    return <div>
        <Button/>
    </div>
}