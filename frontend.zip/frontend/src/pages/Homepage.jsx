import { Topbar } from "../components/Topbar"
export function Homepage(){
    return<div>
        <Topbar/>
    </div>
}
